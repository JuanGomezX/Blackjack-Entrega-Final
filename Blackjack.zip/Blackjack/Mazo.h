/**
 * @class Mazo
 * @brief Representa el conjunto completo de cartas
 *
 * Responsabilidad:
 *  - Generar las 52 cartas de la baraja
 *  - Mezclar el mazo
 *  - Repartir cartas una por una
 *
 * Colaboración:
 *  - Provee cartas a Jugador y Crupier
 *  - Es gestionado por la clase Juego
 */

#ifndef MAZO_H
#define MAZO_H

#include <vector>
#include "Carta.h"

class Mazo
{
private:
    std::vector<Carta> cartas;

public:
    Mazo();
    void generarCartas();
    void barajar();
    Carta repartirCarta();
    int cartasRestantes() const;
};

#endif
