/**
 * @class Carta
 * @brief Representa una carta individual con rango y palo
 *
 * Responsabilidad:
 *  - Almacenar el rango (1–13) y el palo
 *  - Convertir la carta a texto
 *  - Retornar su valor dentro de las reglas de Blackjack
 *
 * Colaboración:
 *  - Es utilizada por Mazo para crear el mazo
 *  - Jugador y Crupier la reciben en sus manos
 */

#ifndef CARTA_H
#define CARTA_H

#include <string>

class Carta
{
public:
    enum class Palo
    {
        CORAZONES,
        DIAMANTES,
        TREBOLES,
        PICAS
    };
    Carta(int rango = 1, Palo palo = Palo::PICAS);
    int getRango() const;
    Palo getPalo() const;
    int ValorBlackjack() const;
    std::string toString() const;

private:
    int rango_;
    Palo palo_;
};
#endif
