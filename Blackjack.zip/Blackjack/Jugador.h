/**
 * @class Jugador
 * @brief Representa al jugador del Blackjack
 *
 * Responsabilidad:
 *  - Almacenar y gestionar la mano del jugador
 *  - Calcular el valor de su mano
 *  - Verificar si se pasó de 21
 *
 * Colaboración:
 *  - Recibe cartas desde Mazo
 *  - Es utilizado tanto por la clase Juego como por Crupier (herencia)
 */

#ifndef JUGADOR_H
#define JUGADOR_H

#include <vector>
#include <string>
#include "Carta.h"

class Jugador
{
private:
    std::string nombre;
    std::vector<Carta> mano;

public:
    Jugador(std::string nombreJugador = "Jugador");
    void recibirCarta(const Carta &carta);
    int calcularValor() const;
    void mostrarMano() const;
    void limpiarMano();
    std::string getNombre() const;
    bool sePaso() const;

    // Métodos de acceso seguros (evitan acceder a 'mano' directamente)
    Carta obtenerPrimeraCarta() const { return mano.empty() ? Carta() : mano[0]; }
    bool tieneCartas() const { return !mano.empty(); }
    int cantidadCartas() const { return static_cast<int>(mano.size()); }
};

#endif
