#include <cassert>
#include <iostream>
#include "Carta.h"
#include "Mazo.h"
#include "Jugador.h"
#include "Crupier.h"
#include "Apuesta.h"
#include "Juego.h"

void testCarta()
{
    Carta c(10, Carta::Palo::CORAZONES);
    assert(c.getRango() == 10);
    assert(c.getPalo() == Carta::Palo::CORAZONES);
    assert(c.ValorBlackjack() == 10);
}

void testMazo()
{
    Mazo mazo;
    mazo.generarCartas();
    assert(mazo.cartasRestantes() == 52);
    Carta c = mazo.repartirCarta();
    assert(mazo.cartasRestantes() == 51);
}

void testJugador()
{
    Jugador j("Juan");
    j.recibirCarta(Carta(10, Carta::Palo::PICAS));
    j.recibirCarta(Carta(1, Carta::Palo::CORAZONES)); // As

    int v = j.calcularValor();
    assert(v == 21);
    assert(j.tieneCartas() == true);
    assert(j.cantidadCartas() == 2);
}

void testCrupier()
{
    Mazo mazo;
    mazo.generarCartas();
    mazo.barajar();

    Crupier c;
    c.recibirCarta(Carta(10, Carta::Palo::PICAS));
    c.recibirCarta(Carta(5, Carta::Palo::DIAMANTES));

    assert(c.calcularValor() == 15);
    assert(c.debePedir() == true); // menor a 17
}

void testApuesta()
{
    Apuesta ap(5000, 50000);

    float pago = ap.calcularPago(true, false, false);
    assert(pago == 7500); // 1.5x por blackjack

    ap.actualizarSaldo(pago);
    assert(ap.getSaldo() == 57500);
}

void testJuego()
{
    Juego juego;

    // No vamos a testear la partida completa porque pide interacción,
    // pero sí que el objeto se construye correctamente.
    assert(true);
}

int main()
{
    std::cout << "Ejecutando pruebas...\n";

    testCarta();
    testMazo();
    testJugador();
    testCrupier();
    testApuesta();
    testJuego();

    std::cout << "Todas las pruebas pasaron correctamente ✔️\n";
    return 0;
}
