/**
 * @file Apuesta.cpp
 * @brief Implementación de los métodos de la clase Apuesta
 *
 * Contiene la lógica para:
 *  - Calcular pagos considerando blackjack
 *  - Actualizar saldo total
 *  - Registrar y mostrar resultados
 */

#include "Apuesta.h"
#include <iostream>

// Constructor
Apuesta::Apuesta(float m, float saldoInicial)
{
    monto = m;
    saldo = saldoInicial;
    resultado = "";
}

// Calcula el pago según el resultado
float Apuesta::calcularPago(bool blackjack, bool gana, bool empate)
{
    float pago = 0;

    if (blackjack)
        pago = monto * 1.5;
    else if (gana)
        pago = monto * 2;
    else if (empate)
        pago = monto;
    else
        pago = 0;

    return pago;
}

// Devuelve el monto apostado
float Apuesta::getMonto() const
{
    return monto;
}

// Devuelve el resultado del juego
std::string Apuesta::getResultado() const
{
    return resultado;
}
// Establece el resultado del juego
void Apuesta::setResultado(std::string r)
{
    resultado = r;
}
// Muestra el saldo actual
void Apuesta::mostrarSaldo() const
{
    std::cout << "Saldo actual: " << saldo << std::endl;
}

// Devuelve el saldo actual
float Apuesta::getSaldo() const
{
    return saldo;
}

// Actualiza el saldo según el pago recibido
void Apuesta::actualizarSaldo(float pago)
{
    saldo += pago;
}
