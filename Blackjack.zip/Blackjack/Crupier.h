/**
 * @class Crupier
 * @brief Modelo del crupier, derivado de la clase Jugador
 *
 * Responsabilidad:
 *  - Ejecutar el turno automático del crupier siguiendo reglas del Blackjack
 *  - Mostrar únicamente la primera carta
 *
 * Colaboración:
 *  - Hereda de Jugador (reutiliza manejo de mano y cálculo de valor)
 *  - Interactúa con Mazo para pedir cartas
 *  - Es controlado por la clase Juego
 */

#ifndef CRUPIER_H
#define CRUPIER_H

#include "Jugador.h"
#include "Mazo.h"

class Crupier : public Jugador
{
public:
    Crupier();
    void jugarTurno(Mazo &mazo);
    void mostrarPrimeraCarta() const;
    bool debePedir() const;
};

#endif
