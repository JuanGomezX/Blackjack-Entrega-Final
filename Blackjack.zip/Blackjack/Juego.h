/**
 * @class Juego
 * @brief Clase principal que coordina toda la lógica del Blackjack
 *
 * Responsabilidad:
 *  - Controlar rondas, turnos y estado del juego
 *  - Coordinar al jugador, crupier, mazo y apuestas
 *  - Determinar el ganador según las reglas del Blackjack
 *
 * Colaboración:
 *  - Usa Jugador, Crupier, Mazo y Apuesta
 *  - Es el controlador principal del programa
 */

#ifndef JUEGO_H
#define JUEGO_H

#include <vector>
#include "Jugador.h"
#include "Crupier.h"
#include "Mazo.h"
#include "Apuesta.h"

class Juego
{
private:
    Jugador jugador;
    Crupier crupier;
    Mazo mazo;
    Apuesta apuesta;
    bool finRonda;

public:
    Juego();
    void iniciarRonda();
    void turnoJugador();
    void turnoCrupier();
    void determinarGanador();
    void mostrarEstadoInicial();
    void reiniciar();
};

#endif
