/**
 * @class Apuesta
 * @brief Gestiona el monto apostado, el saldo del jugador y el resultado de la ronda
 *
 * Responsabilidad:
 *  - Administrar las apuestas hechas por el jugador
 *  - Calcular el pago según el resultado
 *  - Actualizar el saldo total después de cada ronda
 *
 * Colaboración:
 *  - Se usa dentro de la clase Juego, que controla el flujo general
 */

#ifndef APUESTA_H
#define APUESTA_H

#include <iostream>
#include <string>

class Apuesta
{
private:
    float monto;
    float saldo;
    std::string resultado;

public:
    Apuesta(float m = 0, float saldoInicial = 50000);
    float calcularPago(bool blackjack, bool gana, bool empate);
    float getMonto() const;
    std::string getResultado() const;
    void setResultado(std::string r);

    void mostrarSaldo() const;
    float getSaldo() const;
    void actualizarSaldo(float pago);
};

#endif
